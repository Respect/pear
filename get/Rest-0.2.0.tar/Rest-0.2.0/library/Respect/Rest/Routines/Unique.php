<?php

namespace Respect\Rest\Routines;

/** Routine that does not allow multiple instances per route */
interface Unique
{
    
}