<?php

namespace Respect\Validation\Exceptions;

class CallException extends AbstractGroupedException
{
    
}

