<?php

namespace Respect\Validation\Exceptions;

use Exception;

class ComponentException extends Exception
{
    
}

