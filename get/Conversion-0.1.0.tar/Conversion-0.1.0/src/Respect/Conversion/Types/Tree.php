<?php

namespace Respect\Conversion\Types;

class Tree extends AbstractType
{
}
