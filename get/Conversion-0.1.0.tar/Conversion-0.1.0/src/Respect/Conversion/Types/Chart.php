<?php

namespace Respect\Conversion\Types;

class Chart extends AbstractType
{
}
