<?php

namespace Respect\Conversion\Types;

class Collection extends AbstractType
{
}
