<?php

namespace Respect\Conversion\Types;

class Xml extends AbstractType
{
}
