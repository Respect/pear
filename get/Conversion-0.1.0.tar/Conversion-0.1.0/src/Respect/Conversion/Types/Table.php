<?php

namespace Respect\Conversion\Types;

class Table extends AbstractType
{
}
