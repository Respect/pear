<?php

namespace Respect\Conversion\Types;

class AbstractType
{
	public function __construct()
	{
		
	}
}
