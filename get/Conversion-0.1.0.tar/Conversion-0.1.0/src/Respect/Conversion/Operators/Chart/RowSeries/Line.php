<?php

namespace Respect\Conversion\Operators\Chart\Line;

use Respect\Conversion\Operators\Common\Common\AbstractOperator;
use Respect\Conversion\Selectors\Chart\RowSeriesSelectInterface;

class Line extends AbstractOperator implements RowSeriesSelectInterface
{
	public function transform($target)
	{
	}
}