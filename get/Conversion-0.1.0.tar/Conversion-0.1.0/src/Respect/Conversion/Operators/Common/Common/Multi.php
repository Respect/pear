<?php

namespace Respect\Conversion\Operators\Common\Common;

class Multi extends Sequence
{
}