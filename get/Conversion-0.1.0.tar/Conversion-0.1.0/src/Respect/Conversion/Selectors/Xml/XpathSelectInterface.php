<?php

namespace Respect\Conversion\Selectors\Xml;

interface XpathSelectInterface
{
}