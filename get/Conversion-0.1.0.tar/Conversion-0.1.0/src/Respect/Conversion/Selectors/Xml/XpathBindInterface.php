<?php

namespace Respect\Conversion\Selectors\Xml;

interface XpathBindInterface
{
	public function bindToXmlXpath(Xpath $target);
}