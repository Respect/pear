<?php

namespace Respect\Conversion\Selectors\Tree;

interface LeafSelectInterface
{
}