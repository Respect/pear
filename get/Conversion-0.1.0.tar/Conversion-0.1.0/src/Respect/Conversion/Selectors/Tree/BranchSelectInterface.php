<?php

namespace Respect\Conversion\Selectors\Tree;

interface BranchSelectInterface
{
}