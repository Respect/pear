<?php

namespace Respect\Conversion\Selectors\Chart;

interface RowSeriesBindInterface
{
	public function bindToChartRowSeries(RowSeries $selector);
}