<?php

namespace Respect\Conversion\Selectors\Chart;

interface RowSeriesSelectInterface
{
}