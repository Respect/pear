<?php

namespace Respect\Conversion\Selectors\Collection;

use Respect\Conversion\Types\Collection;
use Respect\Conversion\Selectors\Common\AbstractSelector;

class Last extends AbstractSelector implements ItemBindInterface
{
	public function bindToCollectionItem(Item $target)
	{
		
	}
}