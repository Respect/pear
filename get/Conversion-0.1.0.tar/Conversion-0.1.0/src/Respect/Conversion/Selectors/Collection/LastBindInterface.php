<?php

namespace Respect\Conversion\Selectors\Collection;

interface LastBindInterface
{
	public function bindToCollectionLast(Last $selector);
}