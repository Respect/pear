<?php

namespace Respect\Conversion\Selectors\Collection;

interface FirstSelectInterface
{
}