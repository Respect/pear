<?php

namespace Respect\Conversion\Selectors\Collection;

interface FirstBindInterface
{
	public function bindToCollectionFirst(First $selector);
}