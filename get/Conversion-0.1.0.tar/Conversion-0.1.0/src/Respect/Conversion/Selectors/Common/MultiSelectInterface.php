<?php

namespace Respect\Conversion\Selectors\Common;

interface MultiSelectInterface
{
}