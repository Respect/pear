<?php

namespace Respect\Conversion\Selectors\Common;

interface MultiBindInterface
{
	public function bindToMulti(Multi $selector);
}