<?php

namespace Respect\Conversion\Selectors\Common;

abstract class AbstractSelector
{
	public function __construct()
	{
		
	}
}