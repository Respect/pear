<?php

namespace Respect\Conversion\Selectors\Table;

interface TdSelectInterface
{
}