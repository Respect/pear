<?php

namespace Respect\Conversion\Selectors\Table;

interface TrBindInterface
{
	public function bindToTableTr(Tr $selector);
}