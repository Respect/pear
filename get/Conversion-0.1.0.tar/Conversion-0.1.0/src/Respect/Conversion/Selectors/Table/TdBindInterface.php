<?php

namespace Respect\Conversion\Selectors\Table;

interface TdBindInterface
{
	public function bindToTableTd(Td $selector);
}