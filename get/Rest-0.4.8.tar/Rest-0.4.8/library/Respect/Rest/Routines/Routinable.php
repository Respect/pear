<?php

namespace Respect\Rest\Routines;

interface Routinable
{
}
