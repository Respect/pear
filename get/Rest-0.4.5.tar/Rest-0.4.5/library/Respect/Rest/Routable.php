<?php

namespace Respect\Rest;

/** Some class that can be routed by the Router */
interface Routable
{
    
}
